fx_version 'cerulean'
game 'gta5'
-- description Custom water-mark by ThomasSmith

client_scripts {
    'watermark.lua'
}