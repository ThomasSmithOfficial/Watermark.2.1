CZ 

1. Nahraj složku do scriptů.
2. Jdi do watermark.lua a předělej jsi jméno serveru.
3. zapiš script ensure watermark

A pak už jen užívej script💗
       Cread by Thomas


EN

Upload the folder into the scripts.

Go to watermark.lua and change the server name.

Add the line ensure watermark to your script.

And then just enjoy the script 💗
     Created by Thomas       